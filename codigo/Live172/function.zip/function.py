def lambda_handler(request, context):
    return {
        'mensage': 'Nosso lambda automatizado'
    }
